package com.gl.lab;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.lab.entity.CollegeModel;
import com.gl.lab.service.CollegeServiceInf;

@Controller
@RequestMapping("/college")
public class CollegeController {
	@Autowired
	CollegeServiceInf collegeServiceInterface;

	/*
	 * Usage Details //http://localhost:8080//CollegeStudent/college/list no auth
	 * set request type as get
	 */
	@RequestMapping("/list")
	public String loadHome(Model theModel) {
		List<CollegeModel> theCollege = collegeServiceInterface.findAll();// get College from db
		 //add to the spring model
		theModel.addAttribute("CollegeModel", theCollege);// using addattribute we can access this in UI
		return "collegePortal";
	}
	
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {

		// create model attribute to bind form data
		CollegeModel theCollege =  new CollegeModel();
		theModel.addAttribute("student", theCollege);

		return "student_form";
	}

	
	@PostMapping("/save")
	public String saveStudent(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("department") String department, @RequestParam("country") String country) {

		CollegeModel theCollege;
		System.out.print("to save "+name+department+country);
		if (id != 0 && collegeServiceInterface.findById(id) != null) {
			theCollege = collegeServiceInterface.findById(id);
			theCollege.setName(name);
			theCollege.setDepartment(department);
			theCollege.setCountry(country);
		} else {
			theCollege = new CollegeModel(name, department, country);
		}
		// save the College
		collegeServiceInterface.save(theCollege);
		// use a redirect to prevent duplicate submissions
				return "redirect:/college/list";

	}
	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("StudentId") int theId,
			Model theModel) {

		// get the Book from the service
		CollegeModel theCollege = collegeServiceInterface.findById(theId);


		// set Book as a model attribute to pre-populate the form
		theModel.addAttribute("student", theCollege);

		// send over to our form
		return "student_form";			
	}

	
	

	@RequestMapping("/delete")
	public String delete(@RequestParam("StudentId") int theId) {
		// delete the Student
		collegeServiceInterface.deleteById(theId);

		return "redirect:/college/list";

	}

}